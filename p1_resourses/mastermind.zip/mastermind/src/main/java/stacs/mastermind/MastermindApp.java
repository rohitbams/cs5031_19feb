package stacs.mastermind;

import java.io.File;
import java.util.ArrayList;

public class MastermindApp {
    
    public static void main( String[] args ) {
        System.out.println("Welcome to CS5031");
    }

    // Unimplemented skeleton
    // You may refactor this method
    protected static ArrayList<String> loadWordlist(File file) {
        //TODO
        return new ArrayList<String>();
    }
}
